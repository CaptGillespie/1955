const express = require("express");
const app = express();
const mongoose = require('mongoose')
const bodyParser = require('body-parser');


app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));


mongoose.connect('mongodb://localhost/1955', {useNewUrlParser: true});
const PersonSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 2},
}, {timestamps: true})
const Person = mongoose.model('Person', PersonSchema)


    app.get('/', function(req, res) {
        Person.find({}, (err, people) => {
            if (err) {
              res.json(err);
            }
            else {
              res.json(people);
            }
          })
        })



    app.get('/new/:name/', function(req, res) {
        const new_person = new Person({ name: req.params.name})
        new_person.save()
            .then(
                res.redirect('/'))
            .catch(console.log(err))
                res.json(Person);
    });


    app.get('/remove/:name/', function(req, res) {
        Person.remove({name: req.params.name}, (err) => {
            if (err) {
              console.log("Issue deleting: " + err);
            }
            else {
              res.redirect('/');
            }
          })
        })
        
    app.get('/:name', function(req, res){
        Person.findOne({name: req.params.name}, (err, person) =>{
            if (err){
                res.json(err);
            }
            else{
                res.redirect('/');
            }
        })
    })


 app.listen(8000, () => console.log("listening on port 8000"));